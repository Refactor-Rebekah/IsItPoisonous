﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PoisonousApp
{
    public class SpeciesSearch
    {
        public IList<Species> Species { get; set; }
    }
}
